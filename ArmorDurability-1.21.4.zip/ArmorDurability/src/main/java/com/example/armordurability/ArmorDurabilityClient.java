package com.example.armordurability;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Клиентский мод (Fabric 1.21.4, Yarn mappings).
 * Над головой каждого игрока рисует ОДНУ СТРОКУ:
 *   [шлем] 312  [нагрудник] 540  [штаны] 400  [ботинки] 250
 * где цифра — сколько прочности осталось (цвет зависит от процента).
 * Сквозь стены не видно.
 */
public class ArmorDurabilityClient implements ClientModInitializer {

    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final double MAX_DISTANCE = 32.0;
    private static final float SCALE = 0.02f;
    private static final float ICON_SIZE = 10f;
    private static final float ICON_GAP = 2f;
    private static final float PIECE_GAP = 6f;
    private static final double HEIGHT_OFFSET = 0.8;

    private record Piece(ItemStack stack, String text, int color) {}

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null || mc.player == null) return;

            MatrixStack matrices = ctx.matrixStack();
            if (matrices == null) return;

            Vec3d cam = ctx.camera().getPos();
            float tickDelta = ctx.tickCounter().getTickDelta(false);
            TextRenderer tr = mc.textRenderer;

            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                if (p.squaredDistanceTo(mc.player) > MAX_DISTANCE * MAX_DISTANCE) continue;

                List<Piece> pieces = new ArrayList<>();
                float totalWidth = 0f;

                for (EquipmentSlot slot : SLOTS) {
                    ItemStack stack = p.getEquippedStack(slot);
                    if (stack.isEmpty() || !stack.isDamageable()) continue;

                    int max = stack.getMaxDamage();
                    int left = max - stack.getDamage();
                    int percent = Math.round(left * 100f / max);

                    // Цвет с альфой (0xAARRGGBB) — обязательно!
                    int color = percent > 60 ? 0xFF55FF55   // зелёный
                              : percent > 30 ? 0xFFFFFF55   // жёлтый
                              :                0xFFFF5555;  // красный

                    String text = String.valueOf(left);
                    pieces.add(new Piece(stack, text, color));
                    totalWidth += ICON_SIZE + ICON_GAP + tr.getWidth(text);
                }

                if (pieces.isEmpty()) continue;
                totalWidth += PIECE_GAP * (pieces.size() - 1);

                Vec3d pos = p.getLerpedPos(tickDelta);

                matrices.push();
                matrices.translate(
                        pos.x - cam.x,
                        pos.y + p.getHeight() + HEIGHT_OFFSET - cam.y,
                        pos.z - cam.z);
                matrices.multiply(ctx.camera().getRotation());
                matrices.scale(-SCALE, -SCALE, SCALE);

                float x = -totalWidth / 2f;

                for (Piece piece : pieces) {
                    // --- иконка ---
                    matrices.push();
                    matrices.translate(x + ICON_SIZE / 2f, 0f, 0f);
                    matrices.scale(ICON_SIZE, -ICON_SIZE, -ICON_SIZE);
                    ItemRenderState state = new ItemRenderState();
                    mc.getItemModelManager().update(
                            state, piece.stack(), ModelTransformationMode.GUI,
                            false, mc.world, p, 0);
                    state.render(matrices, ctx.consumers(), 0xF000F0, OverlayTexture.DEFAULT_UV);
                    matrices.pop();

                    x += ICON_SIZE + ICON_GAP;

                    // --- цифра ---
                    matrices.push();
                    matrices.translate(0f, 0f, -0.1f);
                    tr.draw(
                            piece.text(),
                            x, -4f,
                            piece.color(),
                            false,
                            matrices.peek().getPositionMatrix(),
                            ctx.consumers(),
                            TextRenderer.TextLayerType.SEE_THROUGH,
                            0,
                            0xF000F0
                    );
                    matrices.pop();

                    x += tr.getWidth(piece.text()) + PIECE_GAP;
                }

                matrices.pop();
            }
        });
    }
}
